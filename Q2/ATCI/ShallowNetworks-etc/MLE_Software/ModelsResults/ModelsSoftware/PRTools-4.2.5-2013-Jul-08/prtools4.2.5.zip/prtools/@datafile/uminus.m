%UMINUS Datafile overload
