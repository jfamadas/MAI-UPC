%SUM Datafile overload
