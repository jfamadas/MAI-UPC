%SIZE Size of datafile. Datafile overload
%
%	[M,K] = SIZE(A)
%
% M: number of objects
% K: number of features
